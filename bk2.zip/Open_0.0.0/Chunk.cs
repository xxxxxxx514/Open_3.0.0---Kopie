﻿using Open_0._0._0.Core;
using Open_0._0._0.World;
using SFML.Graphics;

namespace Open_0._0._0
{
    class Chunk
    {
        public readonly int ChunkX;// grid
        public readonly int ChunkY;

        public const int Size=16; // Tiles pro Chunk
        public Tile[,] Field;     // Die Tiles in diesem Chunk

        public Chunk(int chunkX, int chunkY, int size = 16)
        {
            ChunkX = chunkX;
            ChunkY = chunkY;

            Field = new Tile[size, size];
        }
        public Chunk(int chunkX, int chunkY,Tile[,] field, int size = 16)
        {
            ChunkX = chunkX;
            ChunkY = chunkY;

            Field = field;
        }
        public void Render(RenderWindow renderWindow)
        {
            //LoadTiles();
            for (int x = 0; x < Field.GetLength(0); x++)
            {
                for (int y = 0; y < Field.GetLength(1); y++)
                {
                    renderWindow.Draw(Field[x, y].Shape);
                }
            }
        }
        public void LoadTiles()
        {
            int startX = ChunkX * Size;
            int startY = ChunkY * Size;

            for (int x = 0; x < Size; x++)
                for (int y = 0; y < Size; y++)
                    Field[x, y] = GameWorld.CurrentMap.Field[startX + x, startY + y];
        }

        public Tile[] ToTileArray()
        {
            Tile[] arr = new Tile[Size * Size];
            int index = 0;

            for (int x = 0; x < Size; x++)
            {
                for (int y = 0; y < Size; y++)
                {
                    arr[index++] = Field[x, y];
                }
            }

            return arr;
        }
    }
}
