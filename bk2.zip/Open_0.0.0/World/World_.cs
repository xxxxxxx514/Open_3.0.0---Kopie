﻿using SFML.Graphics;
using SFML.System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Open_0._0._0.World
{
    internal class World_
    {
        private float _unloadTimer = 2f;
        private int _unloadInterval = 2;

        private int _lastCamChunkX = 0;
        private int _lastCamChunkY = 0;
        public Dictionary<Vector2i, Chunk> Chunks { get; private set; } = new();
        public int TotalChunksX { get; } = 11550;
        public int TotalChunksY { get; } = 11550;
        public World_()
        {
        }
        public void Update(float dt)
        {
            _unloadTimer += dt;
            if (_unloadTimer >= _unloadInterval)
            {
                // camPos brauchst du hier — als Feld speichern
                UnloadDistantChunks(_lastCamChunkX, _lastCamChunkY);
                _unloadTimer = 0f;
            }
        }
        private void FillChunks()
        {
            for (int cx = 0; cx < TotalChunksX; cx++)
            {
                for (int cy = 0; cy < TotalChunksY; cy++)
                {
                    var tiles = new Tile[Chunk.Size, Chunk.Size];

                    for (int x = 0; x < Chunk.Size; x++)
                    {
                        for (int y = 0; y < Chunk.Size; y++)
                        {
                            int gridX = cx * Chunk.Size + x;
                            int gridY = cy * Chunk.Size + y;

                            var tile = new Tile(gridX, gridY, TileType.Grass);
                            tile.Shape.Position = new Vector2f(
                                gridX * Tile.TILE_SIZE,
                                gridY * Tile.TILE_SIZE
                            );
                            tiles[x, y] = tile;
                        }
                    }

                    Chunks[new Vector2i(cx, cy)] = new Chunk(cx, cy, tiles);
                }
            }
        }

        // Ersetzt Map.IsTileAtWalkable
        public bool IsTileAtWalkable(int gridX, int gridY)
        {
            int chunkX = gridX / Chunk.Size;
            int chunkY = gridY / Chunk.Size;
            int localX = gridX % Chunk.Size;
            int localY = gridY % Chunk.Size;

            var key = new Vector2i(chunkX, chunkY);
            if (!Chunks.TryGetValue(key, out Chunk chunk)) return false;

            return chunk.Field[localX, localY].isWalkable;
        }

        // Ersetzt Map.DoesTileExist
        public bool DoesTileExist(int gridX, int gridY)
        {
            int chunkX = gridX / Chunk.Size;
            int chunkY = gridY / Chunk.Size;
            return Chunks.ContainsKey(new Vector2i(chunkX, chunkY));
        }

        // Ersetzt Map.GetTileAt
        public Tile GetTileAt(int gridX, int gridY)
        {
            int chunkX = gridX / Chunk.Size;
            int chunkY = gridY / Chunk.Size;
            int localX = gridX % Chunk.Size;
            int localY = gridY % Chunk.Size;

            var key = new Vector2i(chunkX, chunkY);
            if (!Chunks.TryGetValue(key, out Chunk chunk)) return null;

            return chunk.Field[localX, localY];
        }

        // Ersetzt Map.WorldToTile
        public Vector2i WorldToTile(Vector2f pixelPos)
        {
            return new Vector2i(
                (int)pixelPos.X / Tile.TILE_SIZE,
                (int)pixelPos.Y / Tile.TILE_SIZE
            );
        }

        // Render nur sichtbare Chunks
        public void Render(RenderWindow window, Vector2f camPos)
        {
            int camChunkX = (int)camPos.X / Tile.TILE_SIZE / Chunk.Size;
            int camChunkY = (int)camPos.Y / Tile.TILE_SIZE / Chunk.Size;

            // Position merken für Update()
            _lastCamChunkX = camChunkX;
            _lastCamChunkY = camChunkY;

            for (int x = -2; x <= 2; x++)
                for (int y = -2; y <= 2; y++)
                {
                    var key = new Vector2i(camChunkX + x, camChunkY + y);

                    if (!Chunks.ContainsKey(key))
                        LoadChunk(key.X, key.Y);

                    if (Chunks.TryGetValue(key, out Chunk chunk))
                        chunk.Render(window);
                }
        }

        private void LoadChunk(int cx, int cy)
        {
            // Außerhalb der Weltgrenzen → nicht laden
            if (cx < 0 || cy < 0 || cx >= TotalChunksX || cy >= TotalChunksY)
                return;

            var tiles = new Tile[Chunk.Size, Chunk.Size];

            for (int x = 0; x < Chunk.Size; x++)
                for (int y = 0; y < Chunk.Size; y++)
                {
                    int gridX = cx * Chunk.Size + x;
                    int gridY = cy * Chunk.Size + y;

                    var tile = new Tile(gridX, gridY, TileType.Grass);
                    tile.Shape.Position = new Vector2f(
                        gridX * Tile.TILE_SIZE,
                        gridY * Tile.TILE_SIZE
                    );
                    tiles[x, y] = tile;
                }

            Chunks[new Vector2i(cx, cy)] = new Chunk(cx, cy, tiles);
        }
        private void UnloadDistantChunks(int camChunkX, int camChunkY)
        {
            var toRemove = Chunks.Keys
                .Where(k => Math.Abs(k.X - camChunkX) > 4 || Math.Abs(k.Y - camChunkY) > 4)
                .ToList();

            foreach (var key in toRemove)
                Chunks.Remove(key);
        }
        // bestehender Code bleibt...
    }
}
