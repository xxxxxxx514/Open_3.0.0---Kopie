﻿using SFML.Graphics;
using SFML.System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Open_0._0._0.World
{
    internal class World_
    {
        public Dictionary<Vector2i, Chunk> Chunks { get; private set; } = new();
        public int TotalChunksX { get; } = 10;
        public int TotalChunksY { get; } = 10;

        // Ersetzt Map.IsTileAtWalkable
        public bool IsTileAtWalkable(int gridX, int gridY)
        {
            int chunkX = gridX / Chunk.Size;
            int chunkY = gridY / Chunk.Size;
            int localX = gridX % Chunk.Size;
            int localY = gridY % Chunk.Size;

            var key = new Vector2i(chunkX, chunkY);
            if (!Chunks.TryGetValue(key, out Chunk chunk)) return false;

            return chunk.Field[localX, localY].isWalkable;
        }

        // Ersetzt Map.DoesTileExist
        public bool DoesTileExist(int gridX, int gridY)
        {
            int chunkX = gridX / Chunk.Size;
            int chunkY = gridY / Chunk.Size;
            return Chunks.ContainsKey(new Vector2i(chunkX, chunkY));
        }

        // Ersetzt Map.GetTileAt
        public Tile GetTileAt(int gridX, int gridY)
        {
            int chunkX = gridX / Chunk.Size;
            int chunkY = gridY / Chunk.Size;
            int localX = gridX % Chunk.Size;
            int localY = gridY % Chunk.Size;

            var key = new Vector2i(chunkX, chunkY);
            if (!Chunks.TryGetValue(key, out Chunk chunk)) return null;

            return chunk.Field[localX, localY];
        }

        // Ersetzt Map.WorldToTile
        public Vector2i WorldToTile(Vector2f pixelPos)
        {
            return new Vector2i(
                (int)pixelPos.X / Tile.TILE_SIZE,
                (int)pixelPos.Y / Tile.TILE_SIZE
            );
        }

        // Render nur sichtbare Chunks
        public void Render(RenderWindow window, Vector2f camPos)
        {
            int camTileX = (int)camPos.X / Tile.TILE_SIZE;
            int camTileY = (int)camPos.Y / Tile.TILE_SIZE;
            int camChunkX = camTileX / Chunk.Size;
            int camChunkY = camTileY / Chunk.Size;

            for (int x = -2; x <= 2; x++)
                for (int y = -1; y <= 1; y++)
                {
                    var key = new Vector2i(camChunkX + x, camChunkY + y);
                    if (Chunks.TryGetValue(key, out Chunk chunk))
                        chunk.Render(window);
                }
        }

        // bestehender Code bleibt...
    }
}
